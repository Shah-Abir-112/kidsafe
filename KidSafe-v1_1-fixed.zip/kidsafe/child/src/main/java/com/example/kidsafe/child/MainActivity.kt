package com.example.kidsafe.child

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.net.VpnService
import android.provider.Settings
import android.Manifest
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KidSafeTheme {
                Surface(Modifier.fillMaxSize().systemBarsPadding(), color = MaterialTheme.colorScheme.background) { ChildApp() }
            }
        }
    }
}

private enum class Step { PAIR, DISCLOSURE, PERMISSIONS, HOME }

@Composable
fun ChildApp() {
    val ctx = LocalContext.current
    val repo = remember { PairingRepository(ctx.applicationContext) }
    var step by remember {
        mutableStateOf(
            when {
                !repo.isPaired -> Step.PAIR
                !Permissions.allGranted(ctx) -> Step.PERMISSIONS
                else -> Step.HOME
            },
        )
    }
    when (step) {
        Step.PAIR -> PairScreen(repo) { step = Step.DISCLOSURE }
        Step.DISCLOSURE -> DisclosureScreen { step = Step.PERMISSIONS }
        Step.PERMISSIONS -> PermissionScreen(repo) { step = Step.HOME }
        Step.HOME -> HomeScreen(repo)
    }
}

@Composable
private fun PairScreen(repo: PairingRepository, onPaired: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, androidx.compose.ui.Alignment.CenterVertically),
    ) {
        Card(
            Modifier.fillMaxWidth(),
            colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
        ) {
            Column(Modifier.fillMaxWidth().padding(24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("🛡️ KidSafe", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                Text("Your safety, your family's peace of mind.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimary)
                Text("CHILD APP  •  SECURE CONNECTION", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimary)
            }
        }
        Text("Connect to your parent", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Ask your parent to open the Parent app, tap Add child, and share the pairing code.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Your name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = code,
            onValueChange = { code = it },
            label = { Text("Code") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            enabled = !busy && name.isNotBlank() && code.isNotBlank(),
            onClick = {
                busy = true
                error = null
                scope.launch {
                    repo.pair(code, name)
                        .onSuccess { onPaired() }
                        .onFailure {
                            error = it.message ?: "Could not link. Check your internet and try again."
                            busy = false
                        }
                }
            },
        ) { Text(if (busy) "Linking…" else "Link") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

/** Prominent disclosure: shown BEFORE any system permission dialog (required by Google Play). */
@Composable
private fun DisclosureScreen(onContinue: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Before you continue", style = MaterialTheme.typography.headlineSmall)
        Text(
            "This app collects your phone’s location in the background — even when the app is closed " +
                "or not in use — and shares it with the parent you just linked with. " +
                "It also shares your battery level.",
        )
        Text("Why: so your parent can find you if something goes wrong, even if your phone is locked.")
        Text("A notification is always shown while this is on. You will only be asked to allow this once.")
        Text(
            "এই অ্যাপ ব্যাকগ্রাউন্ডে (অ্যাপ বন্ধ থাকলেও) তোমার ফোনের লোকেশন ও ব্যাটারি লেভেল " +
                "তোমার লিঙ্ক করা অভিভাবকের সাথে শেয়ার করবে, যাতে বিপদে তোমাকে খুঁজে পাওয়া যায়। " +
                "চালু থাকলে সবসময় একটি নোটিফিকেশন দেখা যাবে। পারমিশন শুধু একবারই দিতে হবে।",
        )
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
            Text("I understand · বুঝেছি")
        }
    }
}

@Composable
private fun PermissionScreen(repo: PairingRepository, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var fg by remember { mutableStateOf(Permissions.hasForegroundLocation(ctx)) }
    var bg by remember { mutableStateOf(Permissions.hasBackgroundLocation(ctx)) }
    var notif by remember { mutableStateOf(Permissions.hasNotifications(ctx)) }

    // Re-check when the user comes back from the system settings screen.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        fg = Permissions.hasForegroundLocation(ctx)
        bg = Permissions.hasBackgroundLocation(ctx)
        notif = Permissions.hasNotifications(ctx)
    }

    val fgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        fg = Permissions.hasForegroundLocation(ctx)
    }
    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        bg = Permissions.hasBackgroundLocation(ctx)
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notif = Permissions.hasNotifications(ctx)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Allow permissions (one time)", style = MaterialTheme.typography.headlineSmall)

        Text(if (fg) "✅ 1. Location" else "1. Location")
        Button(
            enabled = !fg,
            onClick = {
                fgLauncher.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                )
            },
        ) { Text("Allow location") }

        Text(if (bg) "✅ 2. Location — all the time" else "2. Location — all the time")
        Text(
            "On the next screen choose “Allow all the time”.",
            style = MaterialTheme.typography.bodySmall,
        )
        Button(
            enabled = fg && !bg,
            onClick = { bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION) },
        ) { Text("Allow all the time") }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Text(if (notif) "✅ 3. Notifications" else "3. Notifications")
            Button(
                enabled = !notif,
                onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
            ) { Text("Allow notifications") }
        }

        val ready = fg && bg && notif
        val scope = rememberCoroutineScope()
        Button(
            enabled = ready,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    repo.recordConsent()
                    onDone()
                }
            },
        ) { Text("Finish") }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun HomeScreen(repo: PairingRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sosMessage by remember { mutableStateOf<String?>(null) }
    var talkMessage by remember { mutableStateOf<String?>(null) }
    var shareMinutes by remember { mutableStateOf(ScreenShareService.DEFAULT_MINUTES) }
    var shareMessage by remember { mutableStateOf<String?>(null) }
    val projectionManager = remember {
        ctx.getSystemService(MediaProjectionManager::class.java)
    }
    val shareLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val intent = Intent(ctx, ScreenShareService::class.java).apply {
                putExtra(ScreenShareService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenShareService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenShareService.EXTRA_MINUTES, shareMinutes)
            }
            ContextCompat.startForegroundService(ctx, intent)
            shareMessage = if (shareMinutes == ScreenShareService.ALL_TIME) {
                "Screen sharing started — it will continue until you stop it. " +
                    "A notification stays on screen the whole time."
            } else {
                "Sharing started — ends by itself in $shareMinutes min. " +
                    "A notification stays on screen the whole time."
            }
        } else {
            shareMessage = "Screen sharing was not started."
        }
    }
    var usageOk by remember { mutableStateOf(Permissions.hasUsageAccess(ctx)) }
    var webEnabled by remember { mutableStateOf(WebFilterConfig.isEnabled(ctx)) }
    var webNeedsConsent by remember { mutableStateOf(WebFilterConfig.needsConsent(ctx)) }
    val vpnLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        WebFilterConfig.apply(ctx)
        webNeedsConsent = WebFilterConfig.needsConsent(ctx)
    }

    // The parent can switch web protection on at any time, so keep checking while this screen is open.
    LaunchedEffect(Unit) {
        while (true) {
            webEnabled = WebFilterConfig.isEnabled(ctx)
            webNeedsConsent = WebFilterConfig.needsConsent(ctx)
            delay(2_000)
        }
    }

    // Re-check when the child comes back from the Settings screen.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        usageOk = Permissions.hasUsageAccess(ctx)
    }

    LaunchedEffect(Unit) {
        ContextCompat.startForegroundService(ctx, Intent(ctx, LocationService::class.java))
    }

    LaunchedEffect(usageOk) {
        if (usageOk) {
            repo.recordUsageConsentOnce()
            UsageScheduler.schedule(ctx)
            UsageScheduler.runNow(ctx)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Card(
            Modifier.fillMaxWidth(),
            colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
        ) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("KidSafe", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimary)
                Text("You're connected!", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold)
                Text("Your safety dashboard", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimary)
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("📍 Location sharing is on", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    "Your parent can see your last location and battery, even if your phone is locked. " +
                        "লোকেশন শেয়ারিং চালু আছে।",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }

        if (usageOk) {
            Text("📊 App usage reporting is on", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Your parent can see which apps you used today and for how long.")
        } else {
            // Disclosure shown BEFORE sending the child to the system Settings screen.
            Text("📊 Allow app usage reporting", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "So your parent can see which apps you used today and for how long. " +
                    "Only app names and time are shared — not what you do inside an app. " +
                    "On the next screen, find “KidSafe (Child)” in the list and turn it on. " +
                    "(একবারই করতে হবে। কোন অ্যাপ কতক্ষণ চলেছে শুধু সেটাই অভিভাবক দেখবে। " +
                    "পরের স্ক্রিনে “KidSafe (Child)” খুঁজে চালু করো।)",
            )
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
            ) { Text("Open settings") }
        }

        if (webEnabled && webNeedsConsent) {
            // Disclosure shown BEFORE the Android VPN prompt.
            Text("Allow web protection", style = MaterialTheme.typography.titleMedium)
            Text(
                "Your parent turned on web protection. It blocks adult and unsafe websites. " +
                    "Android will ask you to allow a “VPN connection”. It is only used to check website " +
                    "names — your passwords, messages and what you read are not seen. " +
                    "If you try to open a blocked site, your parent can see the site name. " +
                    "(অভিভাবক ওয়েব প্রোটেকশন চালু করেছেন। এটি শুধু ওয়েবসাইটের নাম দেখে খারাপ সাইট বন্ধ করে — " +
                    "পাসওয়ার্ড বা মেসেজ দেখে না।)",
            )
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val intent = VpnService.prepare(ctx)
                    if (intent != null) {
                        vpnLauncher.launch(intent)
                    } else {
                        WebFilterConfig.apply(ctx)
                        webNeedsConsent = false
                    }
                },
            ) { Text("Turn on web protection") }
        } else if (webEnabled) {
            Text("Web protection is on ✅", style = MaterialTheme.typography.titleMedium)
            Text("Adult and unsafe websites are blocked.")
        }

        Text("Need help right now?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)

        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                repo.sendNeedTalk()
                talkMessage = "Sent. Your parent will reach out to you."
            },
        ) { Text("💬 I need to talk") }
        talkMessage?.let { Text(it) }

        Text("🖥️ Share your screen", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "Only you can start this — your parent cannot turn it on from their side. " +
                "A notification stays on screen the whole time you're sharing, and you can stop " +
                "anytime. It always ends by itself (max 24 hours). " +
                "(শুধু তুমিই এটা চালু করতে পারবে, অভিভাবক দূর থেকে চালু করতে পারবেন না। " +
                "চালু থাকলে সবসময় নোটিফিকেশন দেখা যাবে, এবং যেকোনো সময় বন্ধ করতে পারবে।)",
            style = MaterialTheme.typography.bodySmall,
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            listOf(5, 15, 30, 60, 180, 360, 720, 1440, ScreenShareService.ALL_TIME).forEach { m ->
                FilterChip(
                    selected = shareMinutes == m,
                    onClick = { shareMinutes = m },
                    label = { Text(if (m == ScreenShareService.ALL_TIME) "All time" else if (m < 60) "$m min" else if (m % 60 == 0) "${m / 60} hr" else "$m min") },
                )
            }
        }
        OutlinedButton(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                val intent = projectionManager?.createScreenCaptureIntent()
                if (intent != null) shareLauncher.launch(intent)
            },
        ) { Text("🖥️ Share my screen") }
        shareMessage?.let { Text(it) }

        Button(
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            onClick = {
                scope.launch {
                    repo.sendSos()
                        .onSuccess { sosMessage = "SOS sent to your parent." }
                        .onFailure { sosMessage = it.message ?: "Could not send SOS." }
                }
            },
        ) { Text("🚨 SOS — I need help") }
        sosMessage?.let { Text(it) }
    }
}
