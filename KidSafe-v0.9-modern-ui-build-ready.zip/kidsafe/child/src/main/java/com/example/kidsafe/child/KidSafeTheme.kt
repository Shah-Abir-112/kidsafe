package com.example.kidsafe.child

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

private val KidSafeNavy = Color(0xFF14213D)
private val KidSafeTeal = Color(0xFF0F766E)
private val KidSafeMint = Color(0xFF14B8A6)
private val KidSafeBackground = Color(0xFFF4F7FB)
private val KidSafeSurface = Color(0xFFFFFFFF)
private val KidSafeText = Color(0xFF172033)
private val KidSafeMuted = Color(0xFF64748B)
private val KidSafeError = Color(0xFFB42318)

private val KidSafeColors = lightColorScheme(
    primary = KidSafeTeal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1),
    onPrimaryContainer = Color(0xFF134E4A),
    secondary = KidSafeMint,
    onSecondary = Color(0xFF062E2B),
    background = KidSafeBackground,
    onBackground = KidSafeText,
    surface = KidSafeSurface,
    onSurface = KidSafeText,
    surfaceVariant = Color(0xFFE8EEF5),
    onSurfaceVariant = KidSafeMuted,
    error = KidSafeError,
    onError = Color.White,
)

private val KidSafeShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp),
)

@Composable
fun KidSafeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = KidSafeColors,
        shapes = KidSafeShapes,
        content = content,
    )
}
