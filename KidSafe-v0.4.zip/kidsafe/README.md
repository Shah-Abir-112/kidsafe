# KidSafe — free parental-safety app (Android, Kotlin)

Two apps, one Firebase project (free Spark plan is enough for family use):

- `child/`  — installed on the child's phone
- `parent/` — installed on the parent's phone
- `core/`   — shared constants (collection names, pairing code logic)

## Phase 1 (this scaffold)
- Parent: email sign-in, "Add child" → 8-character pairing code (valid 15 min, single use)
- Child: enter code → plain-language disclosure → one-time permissions → done
- Continuous location sharing (foreground service, always-visible notification,
  balanced-power + 50 m distance filter so it is battery-friendly), restarts after reboot
- Battery % sent with every update → if the phone dies, the parent still sees
  the last known place + battery
- Parent is notified when the child grants permission
- SOS button on the child phone → parent sees alert + location
- Firestore security rules (`firestore.rules`)

## Phase 2: app usage report
- Child turns on "Usage access" once (home screen, with a plain-language explanation first)
- Reports app name + minutes per day (no content), every ~30 min via WorkManager
- Parent: child card -> "App usage" -> last 7 days, bar per app
- Firestore rules gained a `usage` block: re-publish `firestore.rules`
- APKs are now signed with the fixed `debug.keystore`, so later updates install over the old app

## Phase 3: safe places (geofence) + background alerts
- Parent: child card -> "Safe places" -> add Home/School (paste coordinates from Google Maps or use the
  child's last location), radius 150/300/500 m
- Child: places become Google geofences (battery-friendly); enter/exit events go to the parent
- Parent app keeps a small "Safety alerts are on" notification and shows alerts for
  SOS, arrived and left, even when the app is closed (no paid push service needed)
- Firestore rules gained a `places` block: re-publish `firestore.rules`

## Phase 4: location history
- Parent: child card -> "History" -> pick a day (last 7), see the route drawing, a timeline of
  stops ("stayed 08:10-12:40") and open the whole route in Google Maps
- Parent-app only change; no Firestore rule change needed

## Setup
1. Create a Firebase project → enable **Authentication**: Email/Password **and** Anonymous.
2. Create **Firestore** (production mode), then paste `firestore.rules` into Rules → Publish.
3. Register two Android apps in Firebase:
   - `com.example.kidsafe.child`  → download `google-services.json` into `child/`
   - `com.example.kidsafe.parent` → download `google-services.json` into `parent/`
   (Change the package names everywhere first if you want your own.)
4. Open this folder in Android Studio (Ladybug or newer), let Gradle sync, run each module.

## Before publishing on Google Play
- Background location: fill the Play Console "Location permissions" declaration and use the
  in-app disclosure screen (already included) in your review video.
- `targetSdk`: raise it to whatever Play currently requires.
- Keep the app visible on the child's phone (launcher icon + notification). Don't hide it.
- Add a privacy policy URL.

## Next phases
2. Screen time limits + app block (UsageStats + Accessibility/Device Admin)
3. App usage report
4. Geofence alerts + push notifications (FCM) for SOS
5. Web content filter + blocked-attempt alerts
6. Scheduled app lock (study / bedtime)
7. Location history screen, TTL cleanup of old points

Not included on purpose: remote camera, remote microphone, live screen viewing.
