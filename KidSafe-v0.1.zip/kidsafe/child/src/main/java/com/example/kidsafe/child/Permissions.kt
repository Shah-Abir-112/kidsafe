package com.example.kidsafe.child

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

object Permissions {
    fun hasForegroundLocation(c: Context) = granted(c, Manifest.permission.ACCESS_FINE_LOCATION)

    fun hasBackgroundLocation(c: Context) =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.Q ||
            granted(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)

    fun hasNotifications(c: Context) =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            granted(c, Manifest.permission.POST_NOTIFICATIONS)

    fun allGranted(c: Context) =
        hasForegroundLocation(c) && hasBackgroundLocation(c) && hasNotifications(c)

    private fun granted(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED
}
