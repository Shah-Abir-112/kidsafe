package com.example.kidsafe.core

import java.security.SecureRandom

/** Firestore collection names shared by both apps. */
object Col {
    const val PAIRINGS = "pairings"
    const val CHILDREN = "children"
    const val LOCATIONS = "locations"
    const val EVENTS = "events"
}

/** Event types the child app reports to the parent. */
object EventType {
    const val PERMISSION_GRANTED = "permission_granted"
    const val SOS = "sos"
}

/** Short-lived pairing code the parent shows and the child types in. */
object PairingCode {
    // No 0/O/1/I so the code is easy to read out loud.
    private const val ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    const val LENGTH = 8
    const val TTL_MINUTES = 15L

    fun generate(): String {
        val rnd = SecureRandom()
        return buildString { repeat(LENGTH) { append(ALPHABET[rnd.nextInt(ALPHABET.length)]) } }
    }

    fun normalize(input: String): String =
        input.trim().uppercase().filter { it in ALPHABET }
}
