package com.example.kidsafe.parent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.ChatMessage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One-tap preset replies — shown as real buttons above the text field. */
private val QUICK_REPLIES = listOf(
    "👍 Okay, thank you",
    "📞 Calling you now",
    "🚗 Drive safe",
    "❤️ Love you",
)

/** Chat with one linked child. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(child: ChildInfo, parentUid: String, onBack: () -> Unit) {
    val repo = remember { ChatRepository() }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id) {
        val reg = repo.listen(child.id) { messages = it }
        onDispose { reg.remove() }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("💬 ${child.name}") },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
        bottomBar = {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(QUICK_REPLIES) { reply ->
                        Button(onClick = { repo.send(child.id, parentUid, reply) }) { Text(reply) }
                    }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        placeholder = { Text("Message…") },
                        modifier = Modifier.weight(1f),
                    )
                    Button(
                        enabled = input.isNotBlank(),
                        onClick = {
                            repo.send(child.id, parentUid, input)
                            input = ""
                        },
                    ) { Text("Send") }
                }
            }
        },
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            if (messages.isEmpty()) {
                item { Text("No messages yet. Say hi 👋", modifier = Modifier.padding(top = 20.dp)) }
            }
            items(messages, key = { it.id }) { m -> ParentChatBubble(m, timeFormat) }
        }
    }
}

@Composable
private fun ParentChatBubble(m: ChatMessage, timeFormat: SimpleDateFormat) {
    // On the parent's screen, a message the child sent sits on the left.
    val fromChild = m.fromChild
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (fromChild) Arrangement.Start else Arrangement.End) {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = androidx.compose.material3.CardDefaults.cardColors(
                containerColor = if (fromChild) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.primary,
            ),
            modifier = Modifier.widthIn(max = 280.dp),
        ) {
            Column(Modifier.padding(10.dp)) {
                Text(
                    m.text,
                    color = if (fromChild) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimary,
                )
                Text(
                    timeFormat.format(Date(m.time)),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (fromChild) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onPrimary,
                )
            }
        }
    }
}
