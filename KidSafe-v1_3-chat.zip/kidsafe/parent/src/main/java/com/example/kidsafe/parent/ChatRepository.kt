package com.example.kidsafe.parent

import com.example.kidsafe.core.ChatMessage
import com.example.kidsafe.core.Col
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

/**
 * The parent <-> child chat, parent side. Both apps write into the same
 * `children/{childId}/messages` subcollection (see firestore.rules and
 * [com.example.kidsafe.child.ChatRepository] for the child side).
 */
class ChatRepository {

    private val db = FirebaseFirestore.getInstance()

    /** Live updates for one child's chat, oldest first. */
    fun listen(childId: String, onChange: (List<ChatMessage>) -> Unit): ListenerRegistration =
        db.collection(Col.CHILDREN).document(childId)
            .collection(Col.MESSAGES)
            .orderBy("ts", Query.Direction.ASCENDING)
            .limitToLast(500)
            .addSnapshotListener { snap, _ ->
                onChange(snap?.documents.orEmpty().map { it.toChatMessage() })
            }

    /** Sends a message to the child. Delivered live while their Chat screen is open. */
    fun send(childId: String, parentUid: String, text: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return
        db.collection(Col.CHILDREN).document(childId).collection(Col.MESSAGES).add(
            mapOf(
                "senderId" to parentUid,
                "senderRole" to "parent",
                "text" to trimmed,
                "ts" to FieldValue.serverTimestamp(),
            ),
        )
    }
}

private fun DocumentSnapshot.toChatMessage() = ChatMessage(
    id = id,
    fromChild = getString("senderRole") == "child",
    text = getString("text").orEmpty(),
    time = getTimestamp("ts")?.toDate()?.time ?: System.currentTimeMillis(),
)
