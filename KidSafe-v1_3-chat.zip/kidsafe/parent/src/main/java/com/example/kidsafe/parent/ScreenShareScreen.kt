package com.example.kidsafe.parent

import android.graphics.BitmapFactory
import android.text.format.DateUtils
import android.util.Base64
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.google.firebase.firestore.FirebaseFirestore

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenShareScreen(child: ChildInfo, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var active by remember { mutableStateOf(false) }
    var frameBytes by remember { mutableStateOf<ByteArray?>(null) }
    var updatedAt by remember { mutableStateOf<Long?>(null) }
    var endsAt by remember { mutableStateOf<Long?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id) {
        val registration = db.collection(Col.CHILDREN).document(child.id)
            .collection(Col.SCREENSHARE).document("live")
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage
                    return@addSnapshotListener
                }
                active = snap?.getBoolean("active") == true
                val b64 = snap?.getString("frame")
                frameBytes = if (active && !b64.isNullOrEmpty()) {
                    runCatching { Base64.decode(b64, Base64.NO_WRAP) }.getOrNull()
                } else {
                    null
                }
                updatedAt = snap?.getTimestamp("ts")?.toDate()?.time
                endsAt = snap?.getTimestamp("endsAt")?.toDate()?.time
            }
        onDispose { registration.remove() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${child.name} · Screen share") },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Text(
                "Only ${child.name} can start or stop this from their phone. There is no button " +
                    "here to turn it on.",
                style = MaterialTheme.typography.bodySmall,
            )

            val bytes = frameBytes
            if (active && bytes != null) {
                val bmp = remember(bytes) {
                    runCatching { BitmapFactory.decodeByteArray(bytes, 0, bytes.size) }.getOrNull()
                }
                if (bmp != null) {
                    Card(Modifier.fillMaxWidth()) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "${child.name}'s screen",
                            modifier = Modifier.fillMaxWidth(),
                            contentScale = ContentScale.FillWidth,
                        )
                    }
                }
                val freshness = updatedAt?.let {
                    DateUtils.getRelativeTimeSpanString(
                        it, System.currentTimeMillis(), DateUtils.SECOND_IN_MILLIS,
                    ).toString()
                } ?: "just now"
                Text("Updated $freshness · refreshes every couple of seconds", style = MaterialTheme.typography.bodySmall)
                endsAt?.let {
                    val remain = ((it - System.currentTimeMillis()) / 60_000L).coerceAtLeast(0)
                    Text("Ends in about $remain min, or sooner if ${child.name} stops it.")
                }
            } else {
                Text("Not sharing right now.", style = MaterialTheme.typography.titleMedium)
                Text(
                    "If ${child.name} needs to show you something, ask them to open KidSafe and tap " +
                        "“Share my screen”.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}
