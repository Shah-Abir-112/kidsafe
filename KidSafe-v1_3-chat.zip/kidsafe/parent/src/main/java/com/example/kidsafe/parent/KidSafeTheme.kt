package com.example.kidsafe.parent

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

private val KidSafeNavy = Color(0xFF123C9C)
private val KidSafeTeal = Color(0xFF165DFF)
private val KidSafeMint = Color(0xFF55A7FF)
private val KidSafeBackground = Color(0xFFF3F6FC)
private val KidSafeSurface = Color(0xFFFFFFFF)
private val KidSafeText = Color(0xFF172033)
private val KidSafeMuted = Color(0xFF64748B)
private val KidSafeError = Color(0xFFB42318)

private val KidSafeColors = lightColorScheme(
    primary = KidSafeTeal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE4EDFF),
    onPrimaryContainer = Color(0xFF123C9C),
    secondary = KidSafeMint,
    onSecondary = Color(0xFF09275F),
    background = KidSafeBackground,
    onBackground = KidSafeText,
    surface = KidSafeSurface,
    onSurface = KidSafeText,
    surfaceVariant = Color(0xFFEAF0FA),
    onSurfaceVariant = KidSafeMuted,
    error = KidSafeError,
    onError = Color.White,
)

private val KidSafeShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp),
)

@Composable
fun KidSafeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = KidSafeColors,
        shapes = KidSafeShapes,
        content = content,
    )
}
