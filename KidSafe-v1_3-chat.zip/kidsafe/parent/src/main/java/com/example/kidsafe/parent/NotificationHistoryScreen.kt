package com.example.kidsafe.parent

import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun groupLabel(ms: Long, dateFormat: SimpleDateFormat): String = when {
    DateUtils.isToday(ms) -> "Today"
    DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    else -> dateFormat.format(Date(ms))
}

private fun relativeTime(ms: Long): String =
    DateUtils.getRelativeTimeSpanString(ms, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()

/** Every alert this phone received since the app was installed, newest first. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationHistoryScreen(uid: String, onBack: () -> Unit) {
    val appContext = LocalContext.current.applicationContext
    var all by remember { mutableStateOf<List<SavedNotification>>(emptyList()) }
    var total by remember { mutableStateOf(0) }
    var loaded by remember { mutableStateOf(false) }
    var onlyChild by remember { mutableStateOf<String?>(null) }

    // Reading this makes the screen refresh when a new alert arrives while it is open.
    val changes = NotificationStore.version

    BackHandler(onBack = onBack)

    LaunchedEffect(uid, changes) {
        NotificationStore.load(appContext, uid) { list, count ->
            all = list
            total = count
            loaded = true
        }
    }

    // One chip per child (newest name wins, because the list is newest first).
    val children = remember(all) { all.distinctBy { it.childId }.map { it.childId to it.childName } }
    val shown = remember(all, onlyChild) {
        val wanted = onlyChild
        if (wanted == null) all else all.filter { it.childId == wanted }
    }

    val timeFormat = remember { SimpleDateFormat("h:mm a", Locale.getDefault()) }
    val dateFormat = remember { SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()) }
    val dayKeyFormat = remember { SimpleDateFormat("yyyyMMdd", Locale.US) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Notification history") },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            item {
                Text(
                    "Every alert this phone received since you installed the app, newest first.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            if (children.size > 1) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(
                                selected = onlyChild == null,
                                onClick = { onlyChild = null },
                                label = { Text("All") },
                            )
                        }
                        items(children, key = { it.first }) { pair ->
                            FilterChip(
                                selected = onlyChild == pair.first,
                                onClick = { onlyChild = pair.first },
                                label = { Text(pair.second) },
                            )
                        }
                    }
                }
            }

            if (!loaded) {
                item { Text("Loading…") }
            } else if (shown.isEmpty()) {
                item {
                    Text(
                        "No notifications yet. SOS, arrived, left and blocked-site alerts " +
                            "will be saved here.",
                    )
                }
            } else {
                if (total > all.size) {
                    item {
                        Text(
                            "Showing the latest ${all.size} of $total saved alerts.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
                itemsIndexed(shown, key = { _, n -> n.id }) { index, n ->
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        val newDay = index == 0 ||
                            dayKeyFormat.format(Date(shown[index - 1].time)) != dayKeyFormat.format(Date(n.time))
                        if (newDay) {
                            Text(
                                groupLabel(n.time, dateFormat),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(top = 6.dp),
                            )
                        }
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(n.title, style = MaterialTheme.typography.titleMedium)
                                Text(n.text, style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    "${timeFormat.format(Date(n.time))} · ${relativeTime(n.time)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
