package com.example.kidsafe.child

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.Manifest
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize().systemBarsPadding()) { ChildApp() }
            }
        }
    }
}

private enum class Step { PAIR, DISCLOSURE, PERMISSIONS, HOME }

@Composable
fun ChildApp() {
    val ctx = LocalContext.current
    val repo = remember { PairingRepository(ctx.applicationContext) }
    var step by remember {
        mutableStateOf(
            when {
                !repo.isPaired -> Step.PAIR
                !Permissions.allGranted(ctx) -> Step.PERMISSIONS
                else -> Step.HOME
            },
        )
    }
    when (step) {
        Step.PAIR -> PairScreen(repo) { step = Step.DISCLOSURE }
        Step.DISCLOSURE -> DisclosureScreen { step = Step.PERMISSIONS }
        Step.PERMISSIONS -> PermissionScreen(repo) { step = Step.HOME }
        Step.HOME -> HomeScreen(repo)
    }
}

@Composable
private fun PairScreen(repo: PairingRepository, onPaired: () -> Unit) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp, androidx.compose.ui.Alignment.CenterVertically),
    ) {
        Text("Link with your parent", style = MaterialTheme.typography.headlineSmall)
        Text("Ask your parent to open the parent app, tap “Add child”, and read you the code.")
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Your name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
        )
        OutlinedTextField(
            value = code,
            onValueChange = { code = it },
            label = { Text("Code") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
            modifier = Modifier.fillMaxWidth(),
        )
        Button(
            enabled = !busy && name.isNotBlank() && code.isNotBlank(),
            onClick = {
                busy = true
                error = null
                scope.launch {
                    repo.pair(code, name)
                        .onSuccess { onPaired() }
                        .onFailure {
                            error = it.message ?: "Could not link. Check your internet and try again."
                            busy = false
                        }
                }
            },
        ) { Text(if (busy) "Linking…" else "Link") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

/** Prominent disclosure: shown BEFORE any system permission dialog (required by Google Play). */
@Composable
private fun DisclosureScreen(onContinue: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Before you continue", style = MaterialTheme.typography.headlineSmall)
        Text(
            "This app collects your phone’s location in the background — even when the app is closed " +
                "or not in use — and shares it with the parent you just linked with. " +
                "It also shares your battery level.",
        )
        Text("Why: so your parent can find you if something goes wrong, even if your phone is locked.")
        Text("A notification is always shown while this is on. You will only be asked to allow this once.")
        Text(
            "এই অ্যাপ ব্যাকগ্রাউন্ডে (অ্যাপ বন্ধ থাকলেও) তোমার ফোনের লোকেশন ও ব্যাটারি লেভেল " +
                "তোমার লিঙ্ক করা অভিভাবকের সাথে শেয়ার করবে, যাতে বিপদে তোমাকে খুঁজে পাওয়া যায়। " +
                "চালু থাকলে সবসময় একটি নোটিফিকেশন দেখা যাবে। পারমিশন শুধু একবারই দিতে হবে।",
        )
        Button(onClick = onContinue, modifier = Modifier.fillMaxWidth()) {
            Text("I understand · বুঝেছি")
        }
    }
}

@Composable
private fun PermissionScreen(repo: PairingRepository, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var fg by remember { mutableStateOf(Permissions.hasForegroundLocation(ctx)) }
    var bg by remember { mutableStateOf(Permissions.hasBackgroundLocation(ctx)) }
    var notif by remember { mutableStateOf(Permissions.hasNotifications(ctx)) }

    // Re-check when the user comes back from the system settings screen.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        fg = Permissions.hasForegroundLocation(ctx)
        bg = Permissions.hasBackgroundLocation(ctx)
        notif = Permissions.hasNotifications(ctx)
    }

    val fgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        fg = Permissions.hasForegroundLocation(ctx)
    }
    val bgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        bg = Permissions.hasBackgroundLocation(ctx)
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        notif = Permissions.hasNotifications(ctx)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Allow permissions (one time)", style = MaterialTheme.typography.headlineSmall)

        Text(if (fg) "✅ 1. Location" else "1. Location")
        Button(
            enabled = !fg,
            onClick = {
                fgLauncher.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                )
            },
        ) { Text("Allow location") }

        Text(if (bg) "✅ 2. Location — all the time" else "2. Location — all the time")
        Text(
            "On the next screen choose “Allow all the time”.",
            style = MaterialTheme.typography.bodySmall,
        )
        Button(
            enabled = fg && !bg,
            onClick = { bgLauncher.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION) },
        ) { Text("Allow all the time") }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Text(if (notif) "✅ 3. Notifications" else "3. Notifications")
            Button(
                enabled = !notif,
                onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
            ) { Text("Allow notifications") }
        }

        val ready = fg && bg && notif
        val scope = rememberCoroutineScope()
        Button(
            enabled = ready,
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                scope.launch {
                    repo.recordConsent()
                    onDone()
                }
            },
        ) { Text("Finish") }
    }
}

@Composable
private fun HomeScreen(repo: PairingRepository) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sosMessage by remember { mutableStateOf<String?>(null) }
    var usageOk by remember { mutableStateOf(Permissions.hasUsageAccess(ctx)) }

    // Re-check when the child comes back from the Settings screen.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        usageOk = Permissions.hasUsageAccess(ctx)
    }

    LaunchedEffect(Unit) {
        ContextCompat.startForegroundService(ctx, Intent(ctx, LocationService::class.java))
    }

    LaunchedEffect(usageOk) {
        if (usageOk) {
            repo.recordUsageConsentOnce()
            UsageScheduler.schedule(ctx)
            UsageScheduler.runNow(ctx)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Location sharing is on ✅", style = MaterialTheme.typography.headlineSmall)
        Text(
            "Your parent can see your last location and battery, even if your phone is locked. " +
                "লোকেশন শেয়ারিং চালু আছে।",
        )

        if (usageOk) {
            Text("App usage reporting is on ✅", style = MaterialTheme.typography.titleMedium)
            Text("Your parent can see which apps you used today and for how long.")
        } else {
            // Disclosure shown BEFORE sending the child to the system Settings screen.
            Text("Allow app usage reporting", style = MaterialTheme.typography.titleMedium)
            Text(
                "So your parent can see which apps you used today and for how long. " +
                    "Only app names and time are shared — not what you do inside an app. " +
                    "On the next screen, find “KidSafe (Child)” in the list and turn it on. " +
                    "(একবারই করতে হবে। কোন অ্যাপ কতক্ষণ চলেছে শুধু সেটাই অভিভাবক দেখবে। " +
                    "পরের স্ক্রিনে “KidSafe (Child)” খুঁজে চালু করো।)",
            )
            Button(
                modifier = Modifier.fillMaxWidth(),
                onClick = { ctx.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) },
            ) { Text("Open settings") }
        }

        Button(
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            onClick = {
                scope.launch {
                    repo.sendSos()
                        .onSuccess { sosMessage = "SOS sent to your parent." }
                        .onFailure { sosMessage = it.message ?: "Could not send SOS." }
                }
            },
        ) { Text("🚨 SOS — I need help") }
        sosMessage?.let { Text(it) }
    }
}
