package com.example.kidsafe.parent

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth

/** Turns safety alerts back on after the phone restarts (if the parent is still signed in). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (FirebaseAuth.getInstance().currentUser != null) {
            ContextCompat.startForegroundService(context, Intent(context, AlertService::class.java))
        }
    }
}
