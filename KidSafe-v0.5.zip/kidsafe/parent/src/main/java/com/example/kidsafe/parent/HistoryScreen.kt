package com.example.kidsafe.parent

import android.content.Context
import android.content.Intent
import android.location.Location
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos

private const val STOP_RADIUS_M = 100f      // points within 100 m of each other = "same place"
private const val STOP_MIN_MS = 10 * 60_000L // 10+ minutes there = "stayed"

private data class Pt(val lat: Double, val lng: Double, val time: Long, val battery: Int?)

private data class Stop(
    val lat: Double,
    val lng: Double,
    val fromTime: Long,
    val toTime: Long,
    val battery: Int?,
)

private fun DocumentSnapshot.toPt(): Pt? {
    val lat = getDouble("lat") ?: return null
    val lng = getDouble("lng") ?: return null
    val time = getTimestamp("ts")?.toDate()?.time ?: return null
    return Pt(lat, lng, time, getLong("battery")?.toInt())
}

/** Groups consecutive nearby points into "stops" so the timeline stays short and readable. */
private fun buildStops(points: List<Pt>): List<Stop> {
    if (points.isEmpty()) return emptyList()
    val result = mutableListOf<Stop>()
    var first = points[0]
    var last = points[0]
    val out = FloatArray(1)
    for (i in 1 until points.size) {
        val p = points[i]
        Location.distanceBetween(first.lat, first.lng, p.lat, p.lng, out)
        if (out[0] <= STOP_RADIUS_M) {
            last = p
        } else {
            result += Stop(first.lat, first.lng, first.time, last.time, last.battery)
            first = p
            last = p
        }
    }
    result += Stop(first.lat, first.lng, first.time, last.time, last.battery)
    return result
}

private fun dayRange(daysAgo: Int): Pair<Timestamp, Timestamp> {
    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
        add(Calendar.DAY_OF_YEAR, -daysAgo)
    }
    val start = cal.time
    cal.add(Calendar.DAY_OF_YEAR, 1)
    return Timestamp(start) to Timestamp(cal.time)
}

private fun dayLabel(daysAgo: Int): String = when (daysAgo) {
    0 -> "Today"
    1 -> "Yesterday"
    else -> SimpleDateFormat("MMM d", Locale.getDefault()).format(
        Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -daysAgo) }.time,
    )
}

private fun fmtDuration(ms: Long): String {
    val m = ms / 60_000L
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
}

private fun <T> sample(list: List<T>, max: Int): List<T> {
    if (list.size <= max) return list
    return (0 until max).map { i -> list[(i.toLong() * (list.size - 1) / (max - 1)).toInt()] }
}

private fun openPin(ctx: Context, lat: Double, lng: Double, label: String) {
    val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(label)})")
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
}

/** Opens Google Maps with the day's route (start, up to 9 waypoints, end). */
private fun openRoute(ctx: Context, points: List<Pt>) {
    if (points.isEmpty()) return
    val s = sample(points, 11)
    val origin = s.first()
    val dest = s.last()
    val via = s.drop(1).dropLast(1)
    val url = buildString {
        append("https://www.google.com/maps/dir/?api=1")
        append("&origin=${origin.lat},${origin.lng}")
        append("&destination=${dest.lat},${dest.lng}")
        if (via.isNotEmpty()) {
            append("&waypoints=")
            append(via.joinToString("%7C") { "${it.lat},${it.lng}" })
        }
    }
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(child: ChildInfo, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val db = remember { FirebaseFirestore.getInstance() }
    var dayIndex by remember { mutableStateOf(0) }
    var points by remember { mutableStateOf<List<Pt>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val timeFormat = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id, dayIndex) {
        loaded = false
        points = emptyList()
        val (start, end) = dayRange(dayIndex)
        val registration = db.collection(Col.CHILDREN).document(child.id).collection(Col.LOCATIONS)
            .whereGreaterThanOrEqualTo("ts", start)
            .whereLessThan("ts", end)
            .orderBy("ts")
            .limit(1000)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage
                    return@addSnapshotListener
                }
                points = snap?.documents?.mapNotNull { it.toPt() }.orEmpty()
                loaded = true
            }
        onDispose { registration.remove() }
    }

    val stops = remember(points) { buildStops(points) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${child.name} · Location history") },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items((0..6).toList()) { i ->
                        FilterChip(
                            selected = i == dayIndex,
                            onClick = { dayIndex = i },
                            label = { Text(dayLabel(i)) },
                        )
                    }
                }
            }
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }

            if (!loaded) {
                item { Text("Loading…") }
            } else if (points.isEmpty()) {
                item { Text("No location points for this day.") }
            } else {
                item {
                    Text(
                        "${points.size} location points · ${timeFormat.format(Date(points.first().time))} " +
                            "to ${timeFormat.format(Date(points.last().time))}",
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        RouteCanvas(points, Modifier.fillMaxWidth().height(240.dp))
                    }
                }
                item {
                    Text(
                        "🟢 start  🔴 latest. This is a simple drawing of the path. " +
                            "The button below shows the real map (Google may snap the path to roads).",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
                item {
                    Button(onClick = { openRoute(ctx, points) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Open route in Google Maps")
                    }
                }
                item { Text("Timeline", style = MaterialTheme.typography.titleMedium) }
                items(stops) { s ->
                    val stayed = s.toTime - s.fromTime >= STOP_MIN_MS
                    val title = if (stayed) {
                        "${timeFormat.format(Date(s.fromTime))} – ${timeFormat.format(Date(s.toTime))}" +
                            "  (${fmtDuration(s.toTime - s.fromTime)})"
                    } else {
                        timeFormat.format(Date(s.fromTime))
                    }
                    val battery = s.battery?.let { " · 🔋$it%" }.orEmpty()
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(title, style = MaterialTheme.typography.titleSmall)
                                Text(
                                    (if (stayed) "Stayed here" else "Passing by") + battery,
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                            TextButton(onClick = {
                                openPin(ctx, s.lat, s.lng, "${child.name} ${timeFormat.format(Date(s.fromTime))}")
                            }) { Text("Map") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RouteCanvas(points: List<Pt>, modifier: Modifier = Modifier) {
    val lineColor = MaterialTheme.colorScheme.primary
    val startColor = Color(0xFF2E7D32)
    val endColor = Color(0xFFC62828)

    Canvas(modifier) {
        if (points.isEmpty()) return@Canvas
        val pad = 28f
        val minLat = points.minOf { it.lat }
        val maxLat = points.maxOf { it.lat }
        val minLng = points.minOf { it.lng }
        val maxLng = points.maxOf { it.lng }
        val kx = cos(Math.toRadians((minLat + maxLat) / 2)).toFloat()

        val w = ((maxLng - minLng) * kx).toFloat().coerceAtLeast(1e-6f)
        val h = (maxLat - minLat).toFloat().coerceAtLeast(1e-6f)
        val availW = size.width - 2 * pad
        val availH = size.height - 2 * pad
        val scale = minOf(availW / w, availH / h)
        val offX = pad + (availW - w * scale) / 2
        val offY = pad + (availH - h * scale) / 2

        fun at(p: Pt) = Offset(
            offX + ((p.lng - minLng) * kx).toFloat() * scale,
            offY + (maxLat - p.lat).toFloat() * scale,
        )

        val path = Path()
        points.forEachIndexed { i, p ->
            val o = at(p)
            if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
        }
        drawPath(path, lineColor, style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
        drawCircle(startColor, radius = 12f, center = at(points.first()))
        drawCircle(endColor, radius = 12f, center = at(points.last()))
    }
}
