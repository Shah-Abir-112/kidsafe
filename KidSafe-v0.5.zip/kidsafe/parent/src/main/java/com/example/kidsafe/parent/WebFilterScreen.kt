package com.example.kidsafe.parent

import android.text.format.DateUtils
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions

private data class Attempt(val domain: String, val time: Long?, val source: String)

/** "https://www.Example.com/page?x=1" -> "example.com", or null if it doesn't look like a site. */
private fun normalizeDomain(input: String): String? {
    var s = input.trim().lowercase()
        .removePrefix("http://").removePrefix("https://").removePrefix("www.")
    s = s.substringBefore('/').substringBefore('?').substringBefore(':')
    return if (Regex("^[a-z0-9-]+(\\.[a-z0-9-]+)+\$").matches(s)) s else null
}

@Suppress("UNCHECKED_CAST")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebFilterScreen(child: ChildInfo, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    val childRef = remember(child.id) { db.collection(Col.CHILDREN).document(child.id) }
    val settingsRef = remember(child.id) { childRef.collection(Col.SETTINGS).document("webfilter") }

    var enabled by remember { mutableStateOf(false) }
    var domains by remember { mutableStateOf<List<String>>(emptyList()) }
    var active by remember { mutableStateOf(false) }
    var privateDns by remember { mutableStateOf("") }
    var attempts by remember { mutableStateOf<List<Attempt>>(emptyList()) }
    var newDomain by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id) {
        val r1 = settingsRef.addSnapshotListener { snap, e ->
            if (e != null) {
                error = e.localizedMessage
                return@addSnapshotListener
            }
            enabled = snap?.getBoolean("enabled") == true
            domains = (snap?.get("domains") as? List<*>)?.filterIsInstance<String>().orEmpty().sorted()
        }
        val r2 = childRef.addSnapshotListener { snap, _ ->
            val wf = snap?.get("webFilter") as? Map<String, Any?>
            active = wf?.get("active") == true
            privateDns = (wf?.get("privateDns") as? String).orEmpty()
        }
        val r3 = childRef.collection(Col.BLOCKED)
            .orderBy("ts", Query.Direction.DESCENDING)
            .limit(30)
            .addSnapshotListener { snap, _ ->
                attempts = snap?.documents?.mapNotNull { d ->
                    Attempt(
                        domain = d.getString("domain") ?: return@mapNotNull null,
                        time = d.getTimestamp("ts")?.toDate()?.time,
                        source = d.getString("source").orEmpty(),
                    )
                }.orEmpty()
            }
        onDispose {
            r1.remove()
            r2.remove()
            r3.remove()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${child.name} · Web filter") },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }

            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Block adult & unsafe websites", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Uses a family-safe DNS on ${child.name}'s phone. " +
                                "Only website names are checked, nothing else is read.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Switch(
                        checked = enabled,
                        onCheckedChange = { settingsRef.set(mapOf("enabled" to it), SetOptions.merge()) },
                    )
                }
            }

            item {
                Text(
                    when {
                        !enabled -> "Filter is off."
                        active -> "✅ Active on ${child.name}'s phone."
                        else -> "⏳ Waiting. ${child.name} must open the KidSafe app and tap " +
                            "“Turn on web protection” (one time)."
                    },
                )
            }

            if (enabled && privateDns == "hostname") {
                item {
                    Text(
                        "⚠️ ${child.name}'s phone uses a custom “Private DNS”. That can bypass this filter. " +
                            "Set it to Off or Automatic in Settings → Network → Private DNS.",
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }

            item { Text("Also block these sites", style = MaterialTheme.typography.titleMedium) }
            item {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedTextField(
                        value = newDomain,
                        onValueChange = { newDomain = it },
                        label = { Text("example.com") },
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                    )
                    Button(onClick = {
                        val d = normalizeDomain(newDomain)
                        if (d == null) {
                            error = "Enter a site like example.com"
                        } else {
                            settingsRef.set(
                                mapOf("domains" to FieldValue.arrayUnion(d)),
                                SetOptions.merge(),
                            )
                            newDomain = ""
                            error = null
                        }
                    }) { Text("Add") }
                }
            }
            if (domains.isEmpty()) {
                item { Text("No extra sites. (Works only while the filter above is on.)", style = MaterialTheme.typography.bodySmall) }
            }
            items(domains) { d ->
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 16.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(d, Modifier.weight(1f))
                        TextButton(onClick = {
                            settingsRef.set(
                                mapOf("domains" to FieldValue.arrayRemove(d)),
                                SetOptions.merge(),
                            )
                        }) { Text("Remove") }
                    }
                }
            }

            item { Text("Recent blocked attempts", style = MaterialTheme.typography.titleMedium) }
            if (attempts.isEmpty()) {
                item { Text("None yet.", style = MaterialTheme.typography.bodySmall) }
            }
            items(attempts) { a ->
                val whenText = a.time?.let {
                    DateUtils.getRelativeTimeSpanString(it, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()
                } ?: "just now"
                val why = if (a.source == "parent_list") "your list" else "unsafe site"
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("🚫 ${a.domain}", style = MaterialTheme.typography.titleSmall)
                        Text("$whenText · blocked by $why", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
