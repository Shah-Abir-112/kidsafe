package com.example.kidsafe.parent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppRow(val name: String, val ms: Long)
data class DayUsage(val date: String, val totalMs: Long, val apps: List<AppRow>)

@Suppress("UNCHECKED_CAST")
private fun DocumentSnapshot.toDay(): DayUsage {
    val list = (get("apps") as? List<Map<String, Any?>>).orEmpty()
    return DayUsage(
        date = getString("date") ?: id,
        totalMs = getLong("totalMs") ?: 0L,
        apps = list.map {
            AppRow(
                name = (it["name"] as? String) ?: (it["pkg"] as? String) ?: "?",
                ms = (it["ms"] as? Number)?.toLong() ?: 0L,
            )
        },
    )
}

private fun fmt(ms: Long): String {
    val m = ms / 60_000L
    return if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsageScreen(child: ChildInfo, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var days by remember { mutableStateOf<List<DayUsage>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }

    BackHandler(onBack = onBack)

    DisposableEffect(child.id) {
        val registration = db.collection(Col.CHILDREN).document(child.id).collection(Col.USAGE)
            .orderBy("date", Query.Direction.DESCENDING)
            .limit(7)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage
                    return@addSnapshotListener
                }
                days = snap?.documents?.map { it.toDay() }.orEmpty()
                loaded = true
            }
        onDispose { registration.remove() }
    }

    val day = days.getOrNull(selected)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${child.name} · App usage") },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }

            if (days.isEmpty()) {
                item {
                    Text(
                        if (loaded) {
                            "No report yet. It appears after the child turns on usage reporting " +
                                "on their phone (first report within a few minutes, then every ~30 min)."
                        } else {
                            "Loading…"
                        },
                    )
                }
            } else {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        itemsIndexed(days) { i, d ->
                            FilterChip(
                                selected = i == selected,
                                onClick = { selected = i },
                                label = { Text(if (d.date == today) "Today" else d.date.takeLast(5)) },
                            )
                        }
                    }
                }
                if (day != null) {
                    item {
                        Text(
                            "Total app time: ${fmt(day.totalMs)}",
                            style = MaterialTheme.typography.titleMedium,
                        )
                    }
                    val max = (day.apps.maxOfOrNull { it.ms } ?: 1L).coerceAtLeast(1L)
                    items(day.apps) { a ->
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(a.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(fmt(a.ms))
                            }
                            LinearProgressIndicator(
                                progress = { a.ms.toFloat() / max },
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                    }
                }
            }
        }
    }
}
