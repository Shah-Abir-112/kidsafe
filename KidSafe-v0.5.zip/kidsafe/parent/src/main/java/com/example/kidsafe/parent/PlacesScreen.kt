package com.example.kidsafe.parent

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

data class Place(val id: String, val name: String, val lat: Double, val lng: Double, val radius: Int)

private fun DocumentSnapshot.toPlace(): Place? {
    val name = getString("name") ?: return null
    val lat = getDouble("lat") ?: return null
    val lng = getDouble("lng") ?: return null
    return Place(id, name, lat, lng, (getLong("radius") ?: 300L).toInt())
}

/** "23.8103, 90.4125" (as copied from Google Maps) -> lat/lng, or null if it doesn't look right. */
private fun parseCoords(text: String): Pair<Double, Double>? {
    val parts = text.split(",").map { it.trim() }
    if (parts.size != 2) return null
    val lat = parts[0].toDoubleOrNull() ?: return null
    val lng = parts[1].toDoubleOrNull() ?: return null
    return if (lat in -90.0..90.0 && lng in -180.0..180.0) lat to lng else null
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlacesScreen(child: ChildInfo, onBack: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var places by remember { mutableStateOf<List<Place>>(emptyList()) }
    var showAdd by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    BackHandler(onBack = onBack)

    val placesRef = remember(child.id) {
        db.collection(Col.CHILDREN).document(child.id).collection(Col.PLACES)
    }

    DisposableEffect(child.id) {
        val registration = placesRef.addSnapshotListener { snap, e ->
            if (e != null) {
                error = e.localizedMessage
                return@addSnapshotListener
            }
            places = snap?.documents?.mapNotNull { it.toPlace() }.orEmpty()
        }
        onDispose { registration.remove() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${child.name} · Safe places") },
                navigationIcon = { TextButton(onClick = onBack) { Text("‹ Back") } },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = { showAdd = true }) { Text("Add place") }
        },
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Text("You get an alert when ${child.name} arrives at or leaves one of these places.")
            }
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            if (places.isEmpty()) {
                item { Text("No places yet. Tap “Add place” (for example Home or School).") }
            }
            items(places, key = { it.id }) { p ->
                Card(Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 16.dp, top = 8.dp, bottom = 8.dp, end = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text("${p.radius} m around this spot", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { placesRef.document(p.id).delete() }) { Text("Delete") }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddPlaceDialog(
            child = child,
            onDismiss = { showAdd = false },
            onSave = { name, lat, lng, radius ->
                placesRef.add(
                    mapOf(
                        "name" to name,
                        "lat" to lat,
                        "lng" to lng,
                        "radius" to radius,
                        "createdAt" to FieldValue.serverTimestamp(),
                    ),
                )
                showAdd = false
            },
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddPlaceDialog(
    child: ChildInfo,
    onDismiss: () -> Unit,
    onSave: (name: String, lat: Double, lng: Double, radius: Int) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var coords by remember { mutableStateOf("") }
    var radius by remember { mutableStateOf(300) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add place") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name (Home, School…)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = coords,
                    onValueChange = { coords = it },
                    label = { Text("Coordinates: lat, lng") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "Tip: in Google Maps, long-press the place, tap the numbers at the top to copy, then paste here.",
                    style = MaterialTheme.typography.bodySmall,
                )
                if (child.lat != null && child.lng != null) {
                    OutlinedButton(onClick = { coords = "${child.lat}, ${child.lng}" }) {
                        Text("Use ${child.name}'s last location")
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(150, 300, 500).forEach { r ->
                        FilterChip(
                            selected = radius == r,
                            onClick = { radius = r },
                            label = { Text("$r m") },
                        )
                    }
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val ll = parseCoords(coords)
                if (name.isBlank()) {
                    error = "Please enter a name."
                } else if (ll == null) {
                    error = "Enter coordinates like 23.8103, 90.4125"
                } else {
                    onSave(name.trim(), ll.first, ll.second, radius)
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
