package com.example.kidsafe.child

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.provider.Settings
import com.example.kidsafe.core.Col
import com.example.kidsafe.core.EventType
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Website filter. It is a "DNS-only" VPN: ONLY website-name lookups (DNS) are sent through this
 * service. All other traffic (pages, videos, passwords, messages) never touches it.
 *
 *  - lookups for sites on the parent's list get "does not exist"
 *  - everything else is asked to a family-safe DNS (Cloudflare 1.1.1.3, blocks adult + malware)
 *  - blocked lookups are reported to the parent (site name + time, nothing else)
 */
class WebFilterService : VpnService() {

    private var tun: ParcelFileDescriptor? = null
    private var reader: Thread? = null
    @Volatile private var running = false
    @Volatile private var pool: ExecutorService? = null
    @Volatile private var lastEventAt = 0L
    private val lastLogged = ConcurrentHashMap<String, Long>()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        if (!WebFilterConfig.isEnabled(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        val pfd = try {
            Builder()
                .setSession("KidSafe web protection")
                .addAddress(VPN_ADDRESS, 32)
                .addDnsServer(DNS_ADDRESS)
                .addRoute(DNS_ADDRESS, 32) // only the DNS address goes through the tunnel
                .setMtu(1500)
                .setBlocking(true)
                .establish()
        } catch (e: Exception) {
            null
        }
        if (pfd == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        tun = pfd
        running = true
        pool = Executors.newFixedThreadPool(6)
        reader = Thread({ readLoop(pfd) }, "kidsafe-dns").also { it.start() }
        publishStatus(true)
        return START_STICKY
    }

    /** Called by Android when the child (or another VPN app) switches our VPN off. */
    override fun onRevoke() {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid != null && WebFilterConfig.isEnabled(this)) {
            FirebaseFirestore.getInstance().collection(Col.CHILDREN).document(uid).update(
                "lastEvent",
                hashMapOf<String, Any>("type" to EventType.FILTER_OFF, "ts" to FieldValue.serverTimestamp()),
            )
        }
        stopFilter()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopFilter()
        super.onDestroy()
    }

    private fun stopFilter() {
        if (!running && tun == null) return
        running = false
        runCatching { tun?.close() }
        tun = null
        reader?.interrupt()
        reader = null
        pool?.shutdownNow()
        pool = null
        publishStatus(false)
    }

    private fun readLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        try {
            while (running) {
                val n = input.read(buf)
                if (n < 0) break
                if (n == 0) continue
                val packet = buf.copyOf(n)
                pool?.execute { handlePacket(packet, output) }
            }
        } catch (e: Exception) {
            // The tunnel was closed; nothing to do.
        }
    }

    private fun handlePacket(p: ByteArray, out: FileOutputStream) {
        try {
            if (p.size < 28) return
            if (((p[0].toInt() shr 4) and 0xF) != 4) return // IPv4 only
            val ihl = (p[0].toInt() and 0x0F) * 4
            if (p[9].toInt() != 17) return                   // UDP only
            if (p.size < ihl + 8) return
            val srcPort = u16(p, ihl)
            if (u16(p, ihl + 2) != 53) return                // DNS only
            val payloadLen = minOf(u16(p, ihl + 4) - 8, p.size - ihl - 8)
            if (payloadLen < 12) return

            val dns = p.copyOfRange(ihl + 8, ihl + 8 + payloadLen)
            val (domain, questionEnd) = parseQuestion(dns) ?: return

            var blockedBy: String? = null
            val response: ByteArray
            if (WebFilterConfig.matchesCustom(this, domain)) {
                response = nxdomain(dns, questionEnd)
                blockedBy = "parent_list"
            } else {
                response = forward(dns) ?: return
                if (isSinkholed(response)) blockedBy = "unsafe_site"
            }
            if (response.size > 1472) return

            if (blockedBy != null) report(domain, blockedBy)
            val reply = buildReply(p, srcPort, response)
            synchronized(out) { out.write(reply) }
        } catch (e: Exception) {
            // Ignore a bad packet.
        }
    }

    /** Asks the family-safe DNS. Returns null if it can't be reached. */
    private fun forward(dns: ByteArray): ByteArray? {
        for (upstream in UPSTREAMS) {
            try {
                DatagramSocket().use { s ->
                    protect(s)
                    s.soTimeout = 2500
                    s.send(DatagramPacket(dns, dns.size, InetAddress.getByName(upstream), 53))
                    val buf = ByteArray(4096)
                    val resp = DatagramPacket(buf, buf.size)
                    s.receive(resp)
                    return buf.copyOf(resp.length)
                }
            } catch (e: Exception) {
                // try the next one
            }
        }
        return null
    }

    private fun report(domain: String, source: String) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val now = System.currentTimeMillis()
        val prev = lastLogged[domain]
        if (prev != null && now - prev < LOG_EVERY_MS) return
        lastLogged[domain] = now

        val ref = FirebaseFirestore.getInstance().collection(Col.CHILDREN).document(uid)
        ref.collection(Col.BLOCKED).add(
            hashMapOf<String, Any>(
                "domain" to domain,
                "source" to source,
                "ts" to FieldValue.serverTimestamp(),
            ),
        )
        if (now - lastEventAt >= EVENT_EVERY_MS) {
            lastEventAt = now
            // "place" is the generic "what" field of an event; for web events it is the site name.
            ref.update(
                "lastEvent",
                hashMapOf<String, Any>(
                    "type" to EventType.WEB_BLOCKED,
                    "place" to domain,
                    "ts" to FieldValue.serverTimestamp(),
                ),
            )
        }
    }

    private fun publishStatus(active: Boolean) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val privateDns = runCatching {
            Settings.Global.getString(contentResolver, "private_dns_mode")
        }.getOrNull().orEmpty()
        FirebaseFirestore.getInstance().collection(Col.CHILDREN).document(uid).update(
            "webFilter",
            hashMapOf<String, Any>(
                "active" to active,
                "privateDns" to privateDns,
                "at" to FieldValue.serverTimestamp(),
            ),
        )
    }

    private companion object {
        const val VPN_ADDRESS = "10.111.222.1"
        const val DNS_ADDRESS = "10.111.222.2"
        val UPSTREAMS = listOf("1.1.1.3", "1.0.0.3")
        const val LOG_EVERY_MS = 10 * 60_000L
        const val EVENT_EVERY_MS = 5 * 60_000L
    }
}

// ---------------- tiny DNS / IP helpers ----------------

private fun u16(b: ByteArray, i: Int): Int =
    ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)

/** Returns (site name, index just after the question) or null. */
private fun parseQuestion(dns: ByteArray): Pair<String, Int>? {
    var i = 12
    val sb = StringBuilder()
    while (true) {
        if (i >= dns.size) return null
        val len = dns[i].toInt() and 0xFF
        if (len == 0) {
            i++
            break
        }
        if ((len and 0xC0) != 0) return null
        if (i + 1 + len > dns.size) return null
        if (sb.isNotEmpty()) sb.append('.')
        sb.append(String(dns, i + 1, len, Charsets.US_ASCII))
        i += 1 + len
    }
    val end = i + 4
    if (end > dns.size) return null
    return sb.toString().lowercase() to end
}

/** Builds a "this site does not exist" answer from the question. */
private fun nxdomain(dns: ByteArray, questionEnd: Int): ByteArray {
    val r = dns.copyOf(questionEnd)
    r[2] = 0x81.toByte() // response, recursion desired
    r[3] = 0x83.toByte() // recursion available, NXDOMAIN
    for (i in 6..11) r[i] = 0 // no answers / authority / extra records
    return r
}

private fun skipName(r: ByteArray, start: Int): Int {
    var i = start
    while (i < r.size) {
        val len = r[i].toInt() and 0xFF
        if (len == 0) return i + 1
        if ((len and 0xC0) == 0xC0) return i + 2
        i += 1 + len
    }
    return -1
}

/** The family DNS answers blocked sites with 0.0.0.0 (or ::). */
private fun isSinkholed(r: ByteArray): Boolean {
    if (r.size < 12) return false
    val answers = u16(r, 6)
    if (answers == 0) return false
    var i = skipName(r, 12)
    if (i < 0) return false
    i += 4
    repeat(answers) {
        i = skipName(r, i)
        if (i < 0 || i + 10 > r.size) return false
        val type = u16(r, i)
        val rdLen = u16(r, i + 8)
        val rdata = i + 10
        if (rdata + rdLen > r.size) return false
        if ((type == 1 && rdLen == 4) || (type == 28 && rdLen == 16)) {
            if ((rdata until rdata + rdLen).all { r[it].toInt() == 0 }) return true
        }
        i = rdata + rdLen
    }
    return false
}

private fun checksum(b: ByteArray, off: Int, len: Int): Int {
    var sum = 0
    var i = off
    while (i < off + len - 1) {
        sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
        i += 2
    }
    while ((sum shr 16) != 0) sum = (sum and 0xFFFF) + (sum shr 16)
    return sum.inv() and 0xFFFF
}

/** Wraps a DNS answer into an IPv4/UDP packet addressed back to the app that asked. */
private fun buildReply(req: ByteArray, clientPort: Int, dns: ByteArray): ByteArray {
    val total = 20 + 8 + dns.size
    val out = ByteArray(total)
    out[0] = 0x45
    out[2] = (total shr 8).toByte()
    out[3] = total.toByte()
    out[6] = 0x40 // don't fragment
    out[8] = 64   // TTL
    out[9] = 17   // UDP
    System.arraycopy(req, 16, out, 12, 4) // from = the DNS address
    System.arraycopy(req, 12, out, 16, 4) // to   = the app's address
    val ipSum = checksum(out, 0, 20)
    out[10] = (ipSum shr 8).toByte()
    out[11] = ipSum.toByte()

    out[20] = 0
    out[21] = 53
    out[22] = (clientPort shr 8).toByte()
    out[23] = clientPort.toByte()
    val udpLen = 8 + dns.size
    out[24] = (udpLen shr 8).toByte()
    out[25] = udpLen.toByte()
    // UDP checksum 0 = "not used" (allowed for IPv4)
    System.arraycopy(dns, 0, out, 28, dns.size)
    return out
}
