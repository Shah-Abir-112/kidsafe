package com.example.kidsafe.child

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import com.example.kidsafe.core.Col
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Builds today's "which app, how long" report and uploads it.
 * Only app name + minutes are sent. Nothing about what happens inside an app.
 */
object UsageReporter {

    private class App(val pkg: String, val name: String, val ms: Long)

    /** Runs on a background thread (WorkManager). */
    fun report(context: Context) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        if (!Permissions.hasUsageAccess(context)) return

        val start = startOfToday()
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(start))
        val apps = collect(context, start, System.currentTimeMillis())

        val data = mapOf(
            "date" to day,
            "totalMs" to apps.sumOf { it.ms },
            "apps" to apps.map { mapOf("pkg" to it.pkg, "name" to it.name, "ms" to it.ms) },
            "updatedAt" to FieldValue.serverTimestamp(),
        )
        val task = FirebaseFirestore.getInstance()
            .collection(Col.CHILDREN).document(uid)
            .collection(Col.USAGE).document(day)
            .set(data)
        Tasks.await(task, 30, TimeUnit.SECONDS)
    }

    @Suppress("DEPRECATION")
    private fun collect(context: Context, start: Long, end: Long): List<App> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val pm = context.packageManager

        // Don't count our own app, system UI or the home screen.
        val skip = buildSet {
            add(context.packageName)
            add("com.android.systemui")
            pm.resolveActivity(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
                PackageManager.MATCH_DEFAULT_ONLY,
            )?.activityInfo?.packageName?.let { add(it) }
        }

        val totals = HashMap<String, Long>()
        var curPkg: String? = null
        var curStart = 0L

        fun close(pkg: String, at: Long) {
            if (at > curStart) totals[pkg] = (totals[pkg] ?: 0L) + (at - curStart)
        }

        val events = usm.queryEvents(start, end)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> {
                    if (curPkg != pkg) {
                        curPkg?.let { close(it, e.timeStamp) }
                        curPkg = pkg
                        curStart = e.timeStamp
                    }
                }
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    if (curPkg == pkg) {
                        close(pkg, e.timeStamp)
                        curPkg = null
                    }
                }
            }
        }
        curPkg?.let { close(it, end) } // app still open right now

        return totals.entries
            .filter { it.key !in skip && it.value >= 30_000L }
            .sortedByDescending { it.value }
            .take(40)
            .map { App(it.key, labelOf(pm, it.key), it.value) }
    }

    @Suppress("DEPRECATION")
    private fun labelOf(pm: PackageManager, pkg: String): String =
        try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (e: Exception) {
            pkg
        }

    private fun startOfToday(): Long = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
