package com.example.kidsafe.child

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.os.BatteryManager
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.kidsafe.core.Col
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

/**
 * Foreground service that shares location with the parent.
 * A persistent notification is always visible, so the child always knows it is on.
 *
 * Battery: balanced-power mode + a minimum distance filter. If the phone is not moving,
 * almost nothing is sent. Battery % is sent with every update, so if the phone dies the
 * parent still sees the last place + battery level.
 */
class LocationService : Service() {

    private lateinit var client: FusedLocationProviderClient
    private var placesRegistration: ListenerRegistration? = null
    private var lastPlacesSignature: String? = null
    private var settingsRegistration: ListenerRegistration? = null

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.locations.lastOrNull()?.let { upload(it) }
        }
    }

    override fun onCreate() {
        super.onCreate()
        client = LocationServices.getFusedLocationProviderClient(this)
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Location sharing", NotificationManager.IMPORTANCE_LOW),
        )
    }

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION,
            )
        } catch (e: Exception) {
            // Location permission missing/revoked: Android 14+ refuses a location-type service.
            stopSelf()
            return START_NOT_STICKY
        }
        if (!Permissions.hasForegroundLocation(this)) {
            stopSelf()
            return START_NOT_STICKY
        }

        val request = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, UPDATE_INTERVAL_MS)
            .setMinUpdateIntervalMillis(MIN_INTERVAL_MS)
            .setMinUpdateDistanceMeters(MIN_DISTANCE_M)
            .build()
        client.removeLocationUpdates(callback)
        client.requestLocationUpdates(request, callback, Looper.getMainLooper())
        listenForPlaces()
        listenForWebFilter()
        return START_STICKY
    }

    override fun onDestroy() {
        placesRegistration?.remove()
        settingsRegistration?.remove()
        client.removeLocationUpdates(callback)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /** The parent switches the website filter on/off and edits the extra blocked sites. */
    private fun listenForWebFilter() {
        settingsRegistration?.remove()
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        settingsRegistration = FirebaseFirestore.getInstance()
            .collection(Col.CHILDREN).document(uid)
            .collection(Col.SETTINGS).document("webfilter")
            .addSnapshotListener { snap, e ->
                if (e != null || snap == null) return@addSnapshotListener
                // "Missing" from the local cache just means "not loaded yet".
                if (snap.metadata.isFromCache && !snap.exists()) return@addSnapshotListener
                val enabled = snap.getBoolean("enabled") == true
                val domains = (snap.get("domains") as? List<*>)?.filterIsInstance<String>().orEmpty()
                WebFilterConfig.save(applicationContext, enabled, domains)
                WebFilterConfig.apply(applicationContext)
            }
    }

    /** Safe places set by the parent -> Google geofences (battery-friendly, works in background). */
    private fun listenForPlaces() {
        placesRegistration?.remove()
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        placesRegistration = FirebaseFirestore.getInstance()
            .collection(Col.CHILDREN).document(uid).collection(Col.PLACES)
            .addSnapshotListener { snap, e ->
                if (e != null || snap == null) return@addSnapshotListener
                // An empty answer from the local cache just means "not loaded yet".
                if (snap.metadata.isFromCache && snap.isEmpty) return@addSnapshotListener
                val places = snap.documents.mapNotNull { d ->
                    PlaceDef(
                        id = d.id,
                        name = d.getString("name") ?: return@mapNotNull null,
                        lat = d.getDouble("lat") ?: return@mapNotNull null,
                        lng = d.getDouble("lng") ?: return@mapNotNull null,
                        radius = (d.getLong("radius") ?: 300L).toInt(),
                    )
                }
                val signature = places.sortedBy { it.id }.joinToString("|")
                if (signature == lastPlacesSignature) return@addSnapshotListener
                lastPlacesSignature = signature
                GeofenceManager.register(applicationContext, places)
            }
    }

    private fun upload(loc: Location) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val data = hashMapOf<String, Any>(
            "lat" to loc.latitude,
            "lng" to loc.longitude,
            "accuracy" to loc.accuracy,
            "battery" to batteryPercent(),
            "ts" to FieldValue.serverTimestamp(),
        )
        val ref = FirebaseFirestore.getInstance().collection(Col.CHILDREN).document(uid)
        ref.collection(Col.LOCATIONS).add(data) // history
        ref.update("lastLocation", data)         // quick "last known" read for the parent
    }

    private fun batteryPercent(): Int =
        (getSystemService(BATTERY_SERVICE) as BatteryManager)
            .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setContentTitle("Location sharing is on")
            .setContentText("Your parent can see where you are.")
            .setOngoing(true)
            .setContentIntent(
                PendingIntent.getActivity(
                    this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
                ),
            )
            .build()

    private companion object {
        const val CHANNEL_ID = "location_sharing"
        const val NOTIF_ID = 1001
        const val UPDATE_INTERVAL_MS = 5 * 60_000L
        const val MIN_INTERVAL_MS = 2 * 60_000L
        const val MIN_DISTANCE_M = 50f
    }
}
