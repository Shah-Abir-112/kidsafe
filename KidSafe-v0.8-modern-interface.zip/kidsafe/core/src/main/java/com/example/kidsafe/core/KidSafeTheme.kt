package com.example.kidsafe.core

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val KidSafeColors = lightColorScheme(
    primary = Color(0xFF315CE8),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE7ECFF),
    onPrimaryContainer = Color(0xFF172B72),
    secondary = Color(0xFF7357D8),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFF0EAFF),
    onSecondaryContainer = Color(0xFF33216F),
    tertiary = Color(0xFF138A78),
    background = Color(0xFFF6F7FC),
    onBackground = Color(0xFF182033),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF182033),
    surfaceVariant = Color(0xFFEEF1F8),
    onSurfaceVariant = Color(0xFF596276),
    outline = Color(0xFFD9DEEA),
    error = Color(0xFFBA1A1A),
)

private val KidSafeShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun KidSafeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = KidSafeColors,
        shapes = KidSafeShapes,
        content = content,
    )
}
