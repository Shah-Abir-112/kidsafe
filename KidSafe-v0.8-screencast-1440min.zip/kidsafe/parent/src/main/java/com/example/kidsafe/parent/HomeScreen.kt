package com.example.kidsafe.parent

import android.content.Context
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Row
import androidx.compose.runtime.LaunchedEffect
import androidx.core.content.ContextCompat
import android.net.Uri
import android.text.format.DateUtils
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.kidsafe.core.Col
import com.example.kidsafe.core.EventType
import com.example.kidsafe.core.PairingCode
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.util.Date

data class ChildInfo(
    val id: String,
    val name: String,
    val lat: Double?,
    val lng: Double?,
    val battery: Int?,
    val locTime: Long?,
    val eventType: String?,
    val eventTime: Long?,
    val eventLat: Double?,
    val eventLng: Double?,
    val eventPlace: String?,
    val eventMinutes: Int?,
)

@Suppress("UNCHECKED_CAST")
private fun DocumentSnapshot.toChild(): ChildInfo {
    val loc = get("lastLocation") as? Map<String, Any?>
    val ev = get("lastEvent") as? Map<String, Any?>
    return ChildInfo(
        id = id,
        name = getString("name") ?: "Child",
        lat = (loc?.get("lat") as? Number)?.toDouble(),
        lng = (loc?.get("lng") as? Number)?.toDouble(),
        battery = (loc?.get("battery") as? Number)?.toInt(),
        locTime = (loc?.get("ts") as? Timestamp)?.toDate()?.time,
        eventType = ev?.get("type") as? String,
        eventTime = (ev?.get("ts") as? Timestamp)?.toDate()?.time,
        eventLat = (ev?.get("lat") as? Number)?.toDouble(),
        eventLng = (ev?.get("lng") as? Number)?.toDouble(),
        eventPlace = ev?.get("place") as? String,
        eventMinutes = (ev?.get("minutes") as? Number)?.toInt(),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(uid: String, onSignOut: () -> Unit) {
    val db = remember { FirebaseFirestore.getInstance() }
    var children by remember { mutableStateOf<List<ChildInfo>>(emptyList()) }
    var pairingCode by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var usageFor by remember { mutableStateOf<ChildInfo?>(null) }
    var removeTarget by remember { mutableStateOf<ChildInfo?>(null) }
    var placesFor by remember { mutableStateOf<ChildInfo?>(null) }
    var historyFor by remember { mutableStateOf<ChildInfo?>(null) }
    var webFor by remember { mutableStateOf<ChildInfo?>(null) }
    var shareFor by remember { mutableStateOf<ChildInfo?>(null) }

    // Keep listening for SOS / arrived / left in the background (asks for notification permission first).
    val ctx = LocalContext.current
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        ContextCompat.startForegroundService(ctx, Intent(ctx, AlertService::class.java))
    }
    LaunchedEffect(Unit) {
        val needsAsk = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        if (needsAsk) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            ContextCompat.startForegroundService(ctx, Intent(ctx, AlertService::class.java))
        }
    }

    // Live updates: the list refreshes whenever a child's data changes.
    DisposableEffect(uid) {
        val registration = db.collection(Col.CHILDREN)
            .whereEqualTo("parentUid", uid)
            .addSnapshotListener { snap, e ->
                if (e != null) {
                    error = e.localizedMessage
                    return@addSnapshotListener
                }
                children = snap?.documents?.map { it.toChild() }.orEmpty()
            }
        onDispose { registration.remove() }
    }

    val usageChild = usageFor
    if (usageChild != null) {
        UsageScreen(usageChild) { usageFor = null }
        return
    }

    val placesChild = placesFor
    if (placesChild != null) {
        PlacesScreen(placesChild) { placesFor = null }
        return
    }

    val historyChild = historyFor
    if (historyChild != null) {
        HistoryScreen(historyChild) { historyFor = null }
        return
    }

    val webChild = webFor
    if (webChild != null) {
        WebFilterScreen(webChild) { webFor = null }
        return
    }

    val shareChild = shareFor
    if (shareChild != null) {
        ScreenShareScreen(shareChild) { shareFor = null }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("My children") },
                actions = { TextButton(onClick = onSignOut) { Text("Sign out") } },
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = {
                createPairing(db, uid, onCode = { pairingCode = it }, onError = { error = it })
            }) { Text("Add child") }
        },
    ) { padding ->
        LazyColumn(
            Modifier.padding(padding).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
            if (children.isEmpty()) {
                item { Text("No child linked yet. Tap “Add child” and enter the code on their phone.") }
            }
            items(children, key = { it.id }) { c ->
                ChildCard(
                    c,
                    onUsage = { usageFor = c },
                    onPlaces = { placesFor = c },
                    onHistory = { historyFor = c },
                    onWeb = { webFor = c },
                    onShare = { shareFor = c },
                    onRemove = { removeTarget = c },
                )
            }
        }
    }

    pairingCode?.let { code ->
        AlertDialog(
            onDismissRequest = { pairingCode = null },
            confirmButton = { TextButton(onClick = { pairingCode = null }) { Text("Done") } },
            title = { Text("Pairing code") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(code, style = MaterialTheme.typography.displaySmall, fontFamily = FontFamily.Monospace)
                    Text("Enter this code on your child's phone within ${PairingCode.TTL_MINUTES} minutes.")
                }
            },
        )
    }

    removeTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { removeTarget = null },
            title = { Text("Remove ${target.name}?") },
            text = { Text("This unlinks the child from your account and hides their data.") },
            confirmButton = {
                TextButton(onClick = {
                    db.collection(Col.CHILDREN).document(target.id).delete()
                    removeTarget = null
                }) { Text("Remove") }
            },
            dismissButton = { TextButton(onClick = { removeTarget = null }) { Text("Cancel") } },
        )
    }
}

private fun createPairing(
    db: FirebaseFirestore,
    uid: String,
    onCode: (String) -> Unit,
    onError: (String) -> Unit,
) {
    val code = PairingCode.generate()
    val expires = Timestamp(Date(System.currentTimeMillis() + PairingCode.TTL_MINUTES * 60_000L))
    db.collection(Col.PAIRINGS).document(code)
        .set(
            mapOf(
                "parentUid" to uid,
                "used" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "expiresAt" to expires,
            ),
        )
        .addOnSuccessListener { onCode(code) }
        .addOnFailureListener { onError(it.localizedMessage ?: "Could not create code.") }
}

@Composable
private fun ChildCard(
    c: ChildInfo,
    onUsage: () -> Unit,
    onPlaces: () -> Unit,
    onHistory: () -> Unit,
    onWeb: () -> Unit,
    onShare: () -> Unit,
    onRemove: () -> Unit,
) {
    val ctx = LocalContext.current
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(c.name, style = MaterialTheme.typography.titleLarge)

            if (c.lat != null && c.lng != null) {
                val battery = c.battery?.let { " · battery $it%" }.orEmpty()
                Text("Last location ${ago(c.locTime)}$battery")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { openMap(ctx, c.lat, c.lng, c.name) }) { Text("Open in Maps") }
                    OutlinedButton(onClick = onHistory) { Text("History") }
                }
            } else {
                Text("No location received yet.")
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onUsage) { Text("App usage") }
                OutlinedButton(onClick = onPlaces) { Text("Safe places") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onWeb) { Text("Web filter") }
                OutlinedButton(onClick = onShare) { Text("Screen share") }
            }

            when (c.eventType) {
                EventType.SOS -> {
                    Text(
                        "🚨 SOS ${ago(c.eventTime)}",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold,
                    )
                    if (c.eventLat != null && c.eventLng != null) {
                        Button(onClick = { openMap(ctx, c.eventLat, c.eventLng, "${c.name} SOS") }) {
                            Text("Open SOS location")
                        }
                    }
                }
                EventType.PERMISSION_GRANTED ->
                    Text("✅ Child allowed location sharing ${ago(c.eventTime)}")
                EventType.GEOFENCE_ENTER ->
                    Text("📍 Arrived at ${c.eventPlace ?: "a saved place"} ${ago(c.eventTime)}")
                EventType.GEOFENCE_EXIT ->
                    Text("🚶 Left ${c.eventPlace ?: "a saved place"} ${ago(c.eventTime)}")
                EventType.WEB_BLOCKED ->
                    Text("🚫 Blocked site: ${c.eventPlace ?: "?"} ${ago(c.eventTime)}")
                EventType.FILTER_OFF ->
                    Text(
                        "⚠️ Web protection was turned off ${ago(c.eventTime)}",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold,
                    )
                EventType.USAGE_ACCESS_GRANTED ->
                    Text("✅ Child allowed app usage reporting ${ago(c.eventTime)}")
                EventType.NEED_TALK ->
                    Text(
                        "💬 ${c.name} wants to talk ${ago(c.eventTime)}",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold,
                    )
                EventType.SCREEN_SHARE_START ->
                    Text("🖥️ Started sharing screen (${c.eventMinutes ?: "?"} min) ${ago(c.eventTime)}")
                EventType.SCREEN_SHARE_END ->
                    Text("🖥️ Screen sharing ended ${ago(c.eventTime)}")
                else -> {}
            }

            TextButton(onClick = onRemove) { Text("Remove this child") }
        }
    }
}

private fun ago(time: Long?): String =
    if (time == null) "just now"
    else DateUtils.getRelativeTimeSpanString(
        time, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS,
    ).toString()

private fun openMap(ctx: Context, lat: Double, lng: Double, label: String) {
    val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${Uri.encode(label)})")
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
}
